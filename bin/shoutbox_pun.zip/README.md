# shoutbox_pun

shoutbox_box is a [PunBB](https://github.com/punbb/punbb) extension that will place a shoutbox underneath your forum.

# Install

Download [shoutbox_pun.zip](https://github.com/andrewmichaelsmith/shoutbox_pun/blob/master/bin/shoutbox_pun.zip?raw=true) to your extensions directory and unzip (to ./extensions/shoutbox_pun) then install from 'Manage Extensions' in your PunBB forum administration page.

# Screenshot

<img src="https://raw.githubusercontent.com/andrewmichaelsmith/shoutbox_pun/master/bin/screenshot.png" />
