# shoutbox_pun

shoutbox_box is a [PunBB](https://github.com/punbb/punbb) extension that will place a shoutbox underneath your forum.

# Install

Download [shoutbox_pun.zip](https://github.com/downloads/andrewmichaelsmith/shoutbox_pun/shoutbox_pun.zip) to your extensions directory and unzip (to ./extensions/shoutbox_pun) then install from 'Manage Extensions' in your PunBB forum administration page.

# Screenshot

<img src="https://github.com/downloads/andrewmichaelsmith/shoutbox_pun/screenshot.png" />