<?php
/**
* shoutbox_pun
*
* https://github.com/andrewmichaelsmith/shoutbox_pun
*
*
* Copyright (c) 2012 Andrew Smith
*
* Dual licensed under the MIT and GPL licenses:
*   http://www.opensource.org/licenses/mit-license.php
*   http://www.gnu.org/licenses/gpl.html
*/

define("MAX_PAGES", 5);

header("Cache-Control: no-cache");
header("Content-type: text/xml");  
define('FORUM_ROOT', '../../');

define('FORUM_QUIET_VISIT', 1);



require FORUM_ROOT.'include/common.php';
if($_GET['csrf_token'] != generate_form_token('./extensions/shoutbox_pun/data.php'))
{
	print_error("Invalid CSRF Token");
}
else if($_GET['add'] && ($forum_user['id']!=1 || $forum_config['o_shoutbox_pun_guests_can_post']==1))
{


  $msg_to_add = $_GET['add'];
  
  if( (strlen($msg_to_add) > 0) && (strlen($msg_to_add) <= 255) )
  {	
    $query = array(
			'INSERT'	=> 'userid, date, shout',
			'INTO'		=> 'shoutbox_pun',
			'VALUES'	=> '\''.$forum_user['id'].'\', \''.time().'\' , \''.$forum_db->escape($msg_to_add).'\''
		);
		
		$forum_db->query_build($query) or error(__FILE__, __LINE__);
		
		getShouts($_GET['id'],$forum_db,"<iserror>0</iserror>",0);

	}
	else
	{
	  
	  print_error("Message must be greater than 0 characters and shorter than 255 characters");
	  
	}
	
}
else if($_GET['m']=="list" &&  ($forum_user['id']!=1 || $forum_config['o_shoutbox_pun_guests_can_view']==1))
{
	$page = 0;
	
	if(isset($_GET['page']))
	{
		$page = round($_GET['page']);
	}
	
	if($page > MAX_PAGES)
	{
		print_error("That's all the pages you get");
	}
	
	getShouts($_GET['id'],$forum_db,"",$page);
}
else
{
	print_error("Action either not authorised or not recognised"); 	
}
function _make_url_clickable_cb($matches) {
	$ret = '';
	$url = $matches[2];
 
	if ( empty($url) )
		return $matches[0];
	// removed trailing [.,;:] from URL
	if ( in_array(substr($url, -1), array('.', ',', ';', ':')) === true ) {
		$ret = substr($url, -1);
		$url = substr($url, 0, strlen($url)-1);
	}
	return $matches[1] . "<a target=\"_blank\" href=\"".htmlspecialchars($url)."\" rel=\"nofollow\">".htmlspecialchars($url)."</a>" . $ret;
}

 

function xmlEntities($str)
{
	$xml = array('&#34;','&#38;','&#38;','&#60;','&#62;','&#160;','&#161;','&#162;','&#163;','&#164;','&#165;','&#166;','&#167;','&#168;','&#169;','&#170;','&#171;','&#172;','&#173;','&#174;','&#175;','&#176;','&#177;','&#178;','&#179;','&#180;','&#181;','&#182;','&#183;','&#184;','&#185;','&#186;','&#187;','&#188;','&#189;','&#190;','&#191;','&#192;','&#193;','&#194;','&#195;','&#196;','&#197;','&#198;','&#199;','&#200;','&#201;','&#202;','&#203;','&#204;','&#205;','&#206;','&#207;','&#208;','&#209;','&#210;','&#211;','&#212;','&#213;','&#214;','&#215;','&#216;','&#217;','&#218;','&#219;','&#220;','&#221;','&#222;','&#223;','&#224;','&#225;','&#226;','&#227;','&#228;','&#229;','&#230;','&#231;','&#232;','&#233;','&#234;','&#235;','&#236;','&#237;','&#238;','&#239;','&#240;','&#241;','&#242;','&#243;','&#244;','&#245;','&#246;','&#247;','&#248;','&#249;','&#250;','&#251;','&#252;','&#253;','&#254;','&#255;');
	$html = array('&quot;','&amp;','&amp;','&lt;','&gt;','&nbsp;','&iexcl;','&cent;','&pound;','&curren;','&yen;','&brvbar;','&sect;','&uml;','&copy;','&ordf;','&laquo;','&not;','&shy;','&reg;','&macr;','&deg;','&plusmn;','&sup2;','&sup3;','&acute;','&micro;','&para;','&middot;','&cedil;','&sup1;','&ordm;','&raquo;','&frac14;','&frac12;','&frac34;','&iquest;','&Agrave;','&Aacute;','&Acirc;','&Atilde;','&Auml;','&Aring;','&AElig;','&Ccedil;','&Egrave;','&Eacute;','&Ecirc;','&Euml;','&Igrave;','&Iacute;','&Icirc;','&Iuml;','&ETH;','&Ntilde;','&Ograve;','&Oacute;','&Ocirc;','&Otilde;','&Ouml;','&times;','&Oslash;','&Ugrave;','&Uacute;','&Ucirc;','&Uuml;','&Yacute;','&THORN;','&szlig;','&agrave;','&aacute;','&acirc;','&atilde;','&auml;','&aring;','&aelig;','&ccedil;','&egrave;','&eacute;','&ecirc;','&euml;','&igrave;','&iacute;','&icirc;','&iuml;','&eth;','&ntilde;','&ograve;','&oacute;','&ocirc;','&otilde;','&ouml;','&divide;','&oslash;','&ugrave;','&uacute;','&ucirc;','&uuml;','&yacute;','&thorn;','&yuml;');
	$str = str_replace($html,$xml,$str);
	$str = str_ireplace($html,$xml,$str);
	return $str;
}

function getShouts($id,$forum_db,$xml,$page) {


	echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
	echo "<response>\n";
	echo $xml;

	$pageSize = 50;

	
	
	$query = array(
		'SELECT'	=> 'id, userid, date, shout',
		'FROM'		=> 'shoutbox_pun',
		'ORDER BY'	=> 'date DESC',
		'WHERE'     => 'id > '.round($id),
		'LIMIT'		=>  $page*$pageSize .','. $pageSize,
	);
	 
	
	$result = $forum_db->query_build($query) or error(__FILE__, __LINE__);
	 
	 
	$new = $forum_db->num_rows($result);
	 
	 

	 
	$shout = array();
	$username_cache = array();
	$flip_me = array();


	while ($s = $forum_db->fetch_assoc($result))
	{
		$flip_me[] = $s;
	}

	$last_id = $flip_me[0]['id'];

	echo "\t<forumuser>".$forum_user['id']."</forumuser>\n";
	echo "\t<newones>".$new."</newones>\n";
	echo "\t<lastid>".$last_id."</lastid>\n";

	$flip_me = array_reverse($flip_me);

	foreach($flip_me as $shout)
	{
		if(!isset($username_cache[$shout['userid']]))
		{
			$query = array(
        		'SELECT'	=> 'username',
        		'FROM'		=> 'users',
        		'WHERE'	=> 'id = '.$shout['userid']
			);
			$username_res = $forum_db->query_build($query) or error(__FILE__, __LINE__);
			 
			$tmp = $forum_db->fetch_assoc($username_res);
			$username_cache[$shout['userid']] = $tmp['username'];
		}

		echo "\t<message>\n";
		 
		echo "\t\t<id>";
		echo $shout['id'];
		echo "</id>\n";
		 
		echo "\t\t<userid>";
		echo $forum_user['id'];
		echo "</userid>\n";

		echo "\t\t<username>";
		echo $username_cache[$shout['userid']];
		echo "</username>\n";
		 
		echo "\t\t<date>";
		echo $shout['date']+$timediff;
		echo "</date>\n";
		 
		echo "\t\t<text>";
		echo process_msg($shout['shout']);
		echo "</text>\n";

		echo "\t</message>\n";
	}
	 
	echo "<blah>".$ext_info['path']."</blah>";
	echo "</response>";

}

function process_msg($msg) {

    $msg = htmlspecialchars($msg);
    $msg = make_clickable($msg);
    $msg = xmlentities(htmlspecialchars($msg, ENT_QUOTES,'UTF-8'));

    return $msg;

}

function _make_web_ftp_clickable_cb($matches) {
	$ret = '';
	$dest = $matches[2];
	$dest = 'http://' . $dest;
 
	if ( empty($dest) )
		return $matches[0];
	// removed trailing [,;:] from URL
	if ( in_array(substr($dest, -1), array('.', ',', ';', ':')) === true ) {
		$ret = substr($dest, -1);
		$dest = substr($dest, 0, strlen($dest)-1);
	}
	return $matches[1] . "<a href=\"".htmlspecialchars($dest)."\" rel=\"nofollow\">".htmlspecialchars($dest)."</a>" . $ret;
}
 
function _make_email_clickable_cb($matches) {
	$email = $matches[2] . '@' . $matches[3];
	return $matches[1] . "<a href=\"mailto:".htmlspecialchars($email)."\">".htmlspecialchars($email)."</a>";
}
 
function make_clickable($ret) {
	$ret = ' ' . $ret;
	// in testing, using arrays here was found to be faster
	$ret = preg_replace_callback('#([\s>])([\w]+?://[\w\\x80-\\xff\#$%&~/.\-;:=,?@\[\]+]*)#is', '_make_url_clickable_cb', $ret);
	$ret = preg_replace_callback('#([\s>])((www|ftp)\.[\w\\x80-\\xff\#$%&~/.\-;:=,?@\[\]+]*)#is', '_make_web_ftp_clickable_cb', $ret);
	$ret = preg_replace_callback('#([\s>])([.0-9a-z_+-]+)@(([0-9a-z-]+\.)+[0-9a-z]{2,})#i', '_make_email_clickable_cb', $ret);
 
	// this one is not in an array because we need it to run last, for cleanup of accidental links within links
	$ret = preg_replace("#(<a( [^>]+?>|>))<a [^>]+?>([^>]+?)</a></a>#i", "$1$3</a>", $ret);
	$ret = trim($ret);
	return $ret;
}

function print_error($message)
{
	echo "<?xml version=\"1.0\"?>\n";
	echo "<response>\n";
	echo "\t<iserror>";
	echo "1";
	echo "</iserror>\n";
	echo "\t<error>";
	echo $message;
	echo "</error>\n";
	echo "</response>";
	
	exit();
}
?>
